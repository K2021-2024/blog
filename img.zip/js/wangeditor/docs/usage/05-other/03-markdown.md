# 关于 markdown

**好多使用者问到，wangEditor编辑器能否集成markdown？——答案是：富文本编辑器无法和markdown集成到一起。**

-----


你可以参考 [简书](http://www.jianshu.com/) 的实现方式，简书中编辑器也无法实现富文本和`markdown`的自由切换。要么使用富文本编写文章，要么使用`markdown`编写文章，不能公用。

本质上，富文本编辑器和`markdown`编辑器是两回事儿。


